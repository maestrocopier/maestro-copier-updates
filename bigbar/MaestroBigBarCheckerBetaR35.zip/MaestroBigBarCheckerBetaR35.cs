#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private MaestroBigBarChecker[] cacheMaestroBigBarChecker;

		
		public MaestroBigBarChecker MaestroBigBarChecker()
		{
			return MaestroBigBarChecker(Input);
		}


		
		public MaestroBigBarChecker MaestroBigBarChecker(ISeries<double> input)
		{
			if (cacheMaestroBigBarChecker != null)
				for (int idx = 0; idx < cacheMaestroBigBarChecker.Length; idx++)
					if ( cacheMaestroBigBarChecker[idx].EqualsInput(input))
						return cacheMaestroBigBarChecker[idx];
			return CacheIndicator<MaestroBigBarChecker>(new MaestroBigBarChecker(), input, ref cacheMaestroBigBarChecker);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.MaestroBigBarChecker MaestroBigBarChecker()
		{
			return indicator.MaestroBigBarChecker(Input);
		}


		
		public Indicators.MaestroBigBarChecker MaestroBigBarChecker(ISeries<double> input )
		{
			return indicator.MaestroBigBarChecker(input);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.MaestroBigBarChecker MaestroBigBarChecker()
		{
			return indicator.MaestroBigBarChecker(Input);
		}


		
		public Indicators.MaestroBigBarChecker MaestroBigBarChecker(ISeries<double> input )
		{
			return indicator.MaestroBigBarChecker(input);
		}

	}
}

#endregion
