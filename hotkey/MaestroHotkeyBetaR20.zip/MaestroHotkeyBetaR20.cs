#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private MaestroSignalBarHotkey[] cacheMaestroSignalBarHotkey;

		
		public MaestroSignalBarHotkey MaestroSignalBarHotkey(Key longKey, Key shortKey, string templateName, bool allowT1, bool allowT2, bool allowT3, bool allowCustom, decimal wickPercent, decimal bodyPercent, decimal tailPercent)
		{
			return MaestroSignalBarHotkey(Input, longKey, shortKey, templateName, allowT1, allowT2, allowT3, allowCustom, wickPercent, bodyPercent, tailPercent);
		}


		
		public MaestroSignalBarHotkey MaestroSignalBarHotkey(ISeries<double> input, Key longKey, Key shortKey, string templateName, bool allowT1, bool allowT2, bool allowT3, bool allowCustom, decimal wickPercent, decimal bodyPercent, decimal tailPercent)
		{
			if (cacheMaestroSignalBarHotkey != null)
				for (int idx = 0; idx < cacheMaestroSignalBarHotkey.Length; idx++)
					if (cacheMaestroSignalBarHotkey[idx].LongKey == longKey && cacheMaestroSignalBarHotkey[idx].ShortKey == shortKey && cacheMaestroSignalBarHotkey[idx].TemplateName == templateName && cacheMaestroSignalBarHotkey[idx].AllowT1 == allowT1 && cacheMaestroSignalBarHotkey[idx].AllowT2 == allowT2 && cacheMaestroSignalBarHotkey[idx].AllowT3 == allowT3 && cacheMaestroSignalBarHotkey[idx].AllowCustom == allowCustom && cacheMaestroSignalBarHotkey[idx].WickPercent == wickPercent && cacheMaestroSignalBarHotkey[idx].BodyPercent == bodyPercent && cacheMaestroSignalBarHotkey[idx].TailPercent == tailPercent && cacheMaestroSignalBarHotkey[idx].EqualsInput(input))
						return cacheMaestroSignalBarHotkey[idx];
			return CacheIndicator<MaestroSignalBarHotkey>(new MaestroSignalBarHotkey(){ LongKey = longKey, ShortKey = shortKey, TemplateName = templateName, AllowT1 = allowT1, AllowT2 = allowT2, AllowT3 = allowT3, AllowCustom = allowCustom, WickPercent = wickPercent, BodyPercent = bodyPercent, TailPercent = tailPercent }, input, ref cacheMaestroSignalBarHotkey);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.MaestroSignalBarHotkey MaestroSignalBarHotkey(Key longKey, Key shortKey, string templateName, bool allowT1, bool allowT2, bool allowT3, bool allowCustom, decimal wickPercent, decimal bodyPercent, decimal tailPercent)
		{
			return indicator.MaestroSignalBarHotkey(Input, longKey, shortKey, templateName, allowT1, allowT2, allowT3, allowCustom, wickPercent, bodyPercent, tailPercent);
		}


		
		public Indicators.MaestroSignalBarHotkey MaestroSignalBarHotkey(ISeries<double> input , Key longKey, Key shortKey, string templateName, bool allowT1, bool allowT2, bool allowT3, bool allowCustom, decimal wickPercent, decimal bodyPercent, decimal tailPercent)
		{
			return indicator.MaestroSignalBarHotkey(input, longKey, shortKey, templateName, allowT1, allowT2, allowT3, allowCustom, wickPercent, bodyPercent, tailPercent);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.MaestroSignalBarHotkey MaestroSignalBarHotkey(Key longKey, Key shortKey, string templateName, bool allowT1, bool allowT2, bool allowT3, bool allowCustom, decimal wickPercent, decimal bodyPercent, decimal tailPercent)
		{
			return indicator.MaestroSignalBarHotkey(Input, longKey, shortKey, templateName, allowT1, allowT2, allowT3, allowCustom, wickPercent, bodyPercent, tailPercent);
		}


		
		public Indicators.MaestroSignalBarHotkey MaestroSignalBarHotkey(ISeries<double> input , Key longKey, Key shortKey, string templateName, bool allowT1, bool allowT2, bool allowT3, bool allowCustom, decimal wickPercent, decimal bodyPercent, decimal tailPercent)
		{
			return indicator.MaestroSignalBarHotkey(input, longKey, shortKey, templateName, allowT1, allowT2, allowT3, allowCustom, wickPercent, bodyPercent, tailPercent);
		}

	}
}

#endregion
